ATG DIGITAL - İç sayfalar paketi

Bu paket ana sayfayı değiştirmez. Mevcut index.html içindeki bağlantıların açılabilmesi için pages/ klasöründeki sayfaları ekler.

İçindekiler:
- hizmetler.html
- hizmet-sosyal-medya.html
- hizmet-tasarim.html
- hizmet-video-reels.html
- hizmet-reklam-kreatifleri.html
- calismalar.html
- proje-01.html ... proje-04.html
- hakkimizda.html
- iletisim.html

GitHub'a yükleme:
1. ZIP'i indirip aç.
2. Mevcut GitHub deposunda pages adlı klasör oluştur (zaten varsa içine gir).
3. ZIP içindeki pages klasörünün içindeki HTML dosyalarını GitHub'daki pages/ klasörüne yükle.
4. Ana index.html dosyasını değiştirme.
5. Siteyi açıp menüde Hizmetler, Çalışmalar, Hakkımızda ve İletişim bağlantılarını test et.

Notlar:
- Sayfalar kendi CSS'lerini içerir; yeni CSS veya görsel dosyası gerektirmez.
- Portföydeki kartlar konsept örnekleridir; gerçek müşteri işi olarak sunulmamaları için açıkça etiketlenmiştir.
- İletişim formu mailto:info@atgdigital.com üzerinden e-posta taslağı açar. Adres farklıysa iletisim.html içindeki adresi değiştir.
- Mevcut index.html ana sayfa dosyanız olduğu gibi korunur.
