ATG DIGITAL - DÜZELTİLMİŞ HİZMET SAYFALARI

Bu paket, görsellerin GitHub deposunda ana assets klasöründe bulunduğu mevcut yapıya göre düzenlendi.

Yapılacaklar:
1. ZIP içindeki pages klasörüne gir.
2. İçindeki 4 HTML dosyasını ve atg-service-pages.css dosyasını GitHub'daki mevcut pages klasörüne yükle. Aynı adlı dosyaları değiştir (Replace).
3. Görsel dosyalarını yeniden yükleme. Mevcut assets klasöründe social-hero.jpg, social-feed.jpg, social-story.jpg, social-carousel.jpg, social-examples.jpg ve diğer JPG dosyaları kalsın.
4. Commit changes yap ve siteyi yenile.

Ana index.html dosyasına dokunulmadı.
